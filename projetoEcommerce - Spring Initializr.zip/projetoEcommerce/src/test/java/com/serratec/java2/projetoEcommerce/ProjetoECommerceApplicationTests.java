package com.serratec.java2.projetoEcommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoECommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
