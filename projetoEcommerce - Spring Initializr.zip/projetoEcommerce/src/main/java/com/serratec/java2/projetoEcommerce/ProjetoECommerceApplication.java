package com.serratec.java2.projetoEcommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoECommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoECommerceApplication.class, args);
	}

}
